package battleGolf;

public class strint {
	private int space;
	private String name;
	public void setName(String name){
		this.name=name;
	}
	public String getName(){
		return this.name;
	}
	public void setSpace(int space){
		this.space=space;
	}
	public int getSpace(){
		return this.space;
	}

}
